from django.urls import path
from .views import course_list, course_detail, enroll_course,instructor_dashboard,create_course,learner_dashboard
from .views import user_login, user_signup, user_logout,complete_lesson,quiz_view,mark_lesson_completed,generate_certificate,redirect_user,home

urlpatterns = [
    path('', home, name='home'),
    path('', course_list, name='course_list'),
    path('<int:course_id>/', course_detail, name='course_detail'),
    path('/<int:course_id>/enroll_course/', enroll_course, name='enroll_course'),
    path('login/', user_login, name='login'),
    path('signup/', user_signup, name='signup'),
    path('logout/', user_logout, name='logout'),
    path('lesson/<int:lesson_id>/complete_lesson/', complete_lesson, name='complete_lesson'),
    path('instructor/dashboard/', instructor_dashboard, name='instructor_dashboard'),
    path('course/create/', create_course, name='create_course'),
    path('lesson/<int:lesson_id>/quiz/', quiz_view, name='quiz'),
    path('lesson/<int:lesson_id>/complete/', mark_lesson_completed, name='mark_lesson_completed'),
    path('course/<int:course_id>/certificate/', generate_certificate, name='generate_certificate'),
    path('redirect/', redirect_user, name='redirect_user'),
    path('dashboard/',learner_dashboard, name='learner_dashboard'),


]
