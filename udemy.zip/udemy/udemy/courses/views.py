from django.shortcuts import render, get_object_or_404, redirect
from .models import Course, Enrollment
from django.contrib.auth.decorators import login_required
from django.contrib.auth import login, logout, authenticate
from django.contrib.auth.forms import UserCreationForm, AuthenticationForm
from django.http import JsonResponse
from .models import Progress,Quiz,Lesson,LessonCompletion
from django.shortcuts import redirect
from .forms import CourseForm

# List all courses
def course_list(request):
    courses = Course.objects.all()
    return render(request, 'courses/course_list.html', {'courses': courses})

# Course detail page
def course_detail(request, course_id):
    course = get_object_or_404(Course, id=course_id)
    lessons = course.lessons.all()
    return render(request, 'courses/course_detail.html', {'course': course, 'lessons': lessons})

# Enroll in a course
@login_required
def enroll_course(request, course_id):
    course = get_object_or_404(Course, id=course_id)
    if not Enrollment.objects.filter(user=request.user, course=course).exists():
        Enrollment.objects.get_or_create(user=request.user, course=course)
    return redirect('learner_dashboard')

def user_login(request):
    if request.method == "POST":
        form = AuthenticationForm(data=request.POST)
        if form.is_valid():
            user = form.get_user()
            login(request, user)
            return redirect('course_list')
    else:
        form = AuthenticationForm()
    return render(request, 'courses/login.html', {'form': form})

def user_signup(request):
    if request.method == "POST":
        form = UserCreationForm(request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user)
            return redirect('course_list')
    else:
        form = UserCreationForm()
    return render(request, 'courses/signup.html', {'form': form})

def user_logout(request):
    logout(request)
    return redirect('course_list')
# Create your views here.

@login_required
def complete_lesson(request, lesson_id):
    lesson = get_object_or_404(Lesson, id=lesson_id)
    progress, created = Progress.objects.get_or_create(user=request.user, lesson=lesson)
    progress.completed = True
    progress.save()
    return JsonResponse({'status': 'completed'})

@login_required
def instructor_dashboard(request):
    courses = Course.objects.filter(instructor=request.user)
    return render(request, 'courses/instructor_dashboard.html', {'courses': courses})

@login_required
def create_course(request):
    if request.method == 'POST':
        form = CourseForm(request.POST)
        if form.is_valid():
            course = form.save(commit=False)
            course.instructor = request.user
            course.save()
            return redirect('instructor_dashboard')
    else:
        form = CourseForm()
    return render(request, 'courses/create_course.html', {'form': form})
 
def quiz_view(request, lesson_id):
    lesson = get_object_or_404(Lesson, id=lesson_id)
    quizzes = lesson.quizzes.all()
    return render(request, 'courses/quiz.html', {'lesson': lesson, 'quizzes': quizzes})

@login_required
def mark_lesson_completed(request, lesson_id):
    lesson = get_object_or_404(Lesson, id=lesson_id)
    LessonCompletion.objects.get_or_create(user=request.user, lesson=lesson)
    return JsonResponse({'status': 'completed'})

def learner_dashboard(request):
    courses = Course.objects.all()
    progress_data = []

    for course in courses:
        total_lessons = course.lessons.count()
        completed_lessons = LessonCompletion.objects.filter(user=request.user, lesson__course=course).count()
        progress = (completed_lessons / total_lessons) * 100 if total_lessons > 0 else 0

        progress_data.append({
            'course': course,
            'progress': progress,
        })
    return render(request, 'courses/learner_dashboard.html', {'progress_data': progress_data})

from reportlab.lib.pagesizes import letter
from reportlab.pdfgen import canvas
from django.http import FileResponse
import io

def generate_certificate(request, course_id):
    course = get_object_or_404(Course, id=course_id)
    total_lessons = course.lessons.count()
    completed_lessons = LessonCompletion.objects.filter(user=request.user, lesson__course=course).count()

    if completed_lessons < total_lessons:
        return HttpResponse("Complete all lessons to get the certificate", status=400)

    buffer = io.BytesIO()
    c = canvas.Canvas(buffer, pagesize=letter)
    c.setFont("Helvetica-Bold", 20)
    c.drawString(200, 700, "Certificate of Completion")
    c.setFont("Helvetica", 14)
    c.drawString(150, 650, f"This certifies that {request.user.username}")
    c.drawString(150, 620, f"has successfully completed the course:")
    c.setFont("Helvetica-Bold", 16)
    c.drawString(150, 590, f"{course.title}")
    c.drawString(150, 560, f"Instructor: {course.instructor.username}")
    c.showPage()
    c.save()

    buffer.seek(0)
    return FileResponse(buffer, as_attachment=True, filename="certificate.pdf")

def redirect_user(request):
    if request.user.is_authenticated:
        if request.user.is_staff:
            return redirect('instructor_dashboard')
        else:
            return redirect('learner_dashboard')
    return redirect('login')

from django.shortcuts import render
from .models import Course

def home(request):
    courses = Course.objects.all()  # Fetch all available courses
    return render(request, 'courses/home.html', {'courses': courses})
