from django.db import models
from django.contrib.auth import get_user_model

User = get_user_model()

class Course(models.Model):
    COURSE_STATUS_CHOICES = [
        ('pending', 'Pending Approval'),
        ('approved', 'Approved'),
        ('rejected', 'Rejected'),
    ]

    title = models.CharField(max_length=200)
    description = models.TextField()

    created_by = models.ForeignKey(
        User,
        on_delete=models.CASCADE,
        related_name='created_courses'
    )

    assigned_mentor = models.ForeignKey(
        User,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name='assigned_courses',
        limit_choices_to={'role': 'mentor'}
    )

    status = models.CharField(
        max_length=10,
        choices=COURSE_STATUS_CHOICES,
        default='pending'
    )

    enrolled_learners = models.ManyToManyField(
        User,
        related_name='enrolled_courses',
        blank=True
    )

    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return self.title

    def is_enrolled(self, user):
        """
        Check if a user is enrolled in the course.
        """
        return self.enrolled_learners.filter(id=user.id).exists()

    def approve_course(self):
        """
        Approve the course by setting status to 'approved'.
        """
        self.status = 'approved'
        self.save()

    def reject_course(self):
        """
        Reject the course by setting status to 'rejected'.
        """
        self.status = 'rejected'
        self.save()

    def enroll_user(self, user):
        """
        Enroll a user in the course.
        """
        self.enrolled_learners.add(user)
        self.save()

    def unenroll_user(self, user):
        """
        Unenroll a user from the course.
        """
        self.enrolled_learners.remove(user)
        self.save()
