from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.http import HttpResponseForbidden
from django.contrib import messages
from .models import Course
from .forms import CourseForm
from users.models import CustomUser


# Utility: Check course creator or admin
def is_creator_or_admin(user, course):
    return user == course.created_by or user.role == 'admin'


# Create Course
@login_required
def create_course(request):
    user = request.user
    if user.role not in ['admin', 'mentor']:
        return HttpResponseForbidden("You are not allowed to create courses.")

    if request.method == 'POST':
        form = CourseForm(request.POST)
        if form.is_valid():
            course = form.save(commit=False)
            course.created_by = user

            if user.role == 'admin':
                course.status = 'approved'
                mentor_id = request.POST.get('mentor')
                if mentor_id:
                    mentor = CustomUser.objects.filter(id=mentor_id, role='mentor').first()
                    course.assigned_mentor = mentor
            elif user.role == 'mentor':
                course.status = 'pending'
                course.assigned_mentor = user

            course.save()
            messages.success(request, 'Course created successfully!')
            return redirect('course_list')
    else:
        form = CourseForm()

    mentors = CustomUser.objects.filter(role='mentor') if user.role == 'admin' else None
    return render(request, 'course/create_course.html', {'form': form, 'mentors': mentors})


# Update Course
@login_required
def update_course(request, course_id):
    course = get_object_or_404(Course, id=course_id)
    user = request.user

    if not is_creator_or_admin(user, course):
        return HttpResponseForbidden("You are not allowed to edit this course.")

    if request.method == 'POST':
        form = CourseForm(request.POST, instance=course)
        if form.is_valid():
            course = form.save(commit=False)

            if user.role == 'admin':
                course.status = 'approved'
                mentor_id = request.POST.get('mentor')
                if mentor_id:
                    mentor = CustomUser.objects.filter(id=mentor_id, role='mentor').first()
                    course.assigned_mentor = mentor

            course.save()
            return redirect('course_list')
    else:
        form = CourseForm(instance=course)

    mentors = CustomUser.objects.filter(role='mentor') if user.role == 'admin' else None
    return render(request, 'course/create_course.html', {'form': form, 'mentors': mentors})


# Delete Course
@login_required
def delete_course(request, course_id):
    course = get_object_or_404(Course, id=course_id)

    if not is_creator_or_admin(request.user, course):
        return HttpResponseForbidden("You do not have permission to delete this course.")

    course.delete()
    messages.success(request, f"Course '{course.title}' has been deleted.")
    return redirect('course_list')


# Course List Views (Role-based)
@login_required
def course_list(request):
    user = request.user

    if user.role == 'admin':
        courses = Course.objects.all()
    elif user.role == 'mentor':
        courses = Course.objects.filter(assigned_mentor=user)
    else:
        courses = Course.objects.filter(status='approved', enrolled_learners=user)

    return render(request, 'course/course_list.html', {'courses': courses})


# My Courses (Learner)
@login_required
def my_courses(request):
    if request.user.role != 'learner':
        return HttpResponseForbidden("Only learners can view their enrolled courses.")
    courses = Course.objects.filter(enrolled_learners=request.user)
    return render(request, 'course/my_courses.html', {'courses': courses})


# Mentor Assigned Courses
@login_required
def mentor_assigned_courses(request):
    if request.user.role != 'mentor':
        return HttpResponseForbidden("You are not authorized to view this page.")
    courses = Course.objects.filter(assigned_mentor=request.user)
    return render(request, 'course/mentor_assigned_courses.html', {'courses': courses})


# Admin: View Pending Courses
@login_required
def approve_courses(request):
    if request.user.role != 'admin':
        return HttpResponseForbidden("Only admin can access this page.")
    courses = Course.objects.filter(status='pending')
    return render(request, 'course/approve_courses.html', {'courses': courses})


# Admin: Approve/Reject Course
@login_required
def approve_or_reject_course(request, course_id):
    if request.user.role != 'admin':
        return HttpResponseForbidden("Only admin can approve/reject courses.")

    course = get_object_or_404(Course, id=course_id)
    mentors = CustomUser.objects.filter(role='mentor')

    if request.method == 'POST':
        status = request.POST.get('status')
        mentor_id = request.POST.get('mentor')

        if status in ['approved', 'rejected']:
            course.status = status

        if mentor_id:
            mentor = CustomUser.objects.filter(id=mentor_id, role='mentor').first()
            if mentor:
                course.assigned_mentor = mentor
            else:
                messages.error(request, "Mentor not found.")

        course.save()
        messages.success(request, f"Course '{course.title}' has been updated.")
        return redirect('approve_courses')

    return render(request, 'course/approve_course.html', {
        'course': course,
        'mentors': mentors
    })


# Learner: Request Enrollment
@login_required
def request_enrollment(request, course_id):
    course = get_object_or_404(Course, id=course_id)

    if request.user.role == 'learner':
        if course.status == 'approved':
            course.enrolled_learners.add(request.user)
            messages.success(request, 'Enrollment request submitted.')
        else:
            messages.error(request, 'Course is not approved yet.')

    return redirect('course_list')
