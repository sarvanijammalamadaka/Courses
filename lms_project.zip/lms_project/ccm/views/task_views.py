# ccm/views.py

from django.shortcuts import render, get_object_or_404, redirect
from django.contrib.auth.decorators import login_required

from ccm.forms import QuizOptionFormSet, QuizQuestionForm, TaskForm, VideoContentForm
from ccm.models import Task, VideoContent
from course.models import Course


@login_required
def task_list(request, course_id):
    course = get_object_or_404(Course, id=course_id)
    tasks = course.tasks.all()
    return render(request, 'ccm/task_list.html', {'course': course, 'tasks': tasks})

@login_required
def create_task(request, course_id):
    course = get_object_or_404(Course, id=course_id)

    if request.method == 'POST':
        form = TaskForm(request.POST)
        if form.is_valid():
            task = form.save(commit=False)
            task.course = course
            task.save()
            return redirect('ccm:task_list', course_id=course.id)
    else:
        form = TaskForm()

    return render(request, 'ccm/task_form.html', {'form': form, 'course': course})

@login_required
def update_task(request, pk):
    task = get_object_or_404(Task, pk=pk)
    form = TaskForm(request.POST or None, instance=task)

    if form.is_valid():
        form.save()
        return redirect('ccm:task_list', course_id=task.course.id)

    return render(request, 'ccm/task_form.html', {'form': form, 'course': task.course})

@login_required
def delete_task(request, pk):
    task = get_object_or_404(Task, pk=pk)
    if request.method == 'POST':
        task.delete()
        return redirect('ccm:task_list', course_id=task.course.id)
    return render(request, 'ccm/task_confirm_delete.html', {'task': task})
# ccm/views/task_views.py


from django.shortcuts import render, redirect, get_object_or_404

from django.contrib.auth.decorators import login_required

@login_required
def add_video(request, task_id):
    task = get_object_or_404(Task, id=task_id)
    if request.method == 'POST':
        form = VideoContentForm(request.POST)
        if form.is_valid():
            video = form.save(commit=False)
            video.task = task
            video.save()
            return redirect('task_detail', task_id=task.id)
    else:
        form = VideoContentForm()
    return render(request, 'ccm/video/add_video.html', {'form': form, 'task': task})

@login_required
def delete_video(request, video_id):
    video = get_object_or_404(VideoContent, id=video_id)
    task_id = video.task.id
    video.delete()
    return redirect('task_detail', task_id=task_id)

@login_required
def add_quiz(request, task_id):
    task = get_object_or_404(Task, id=task_id)
    if request.method == 'POST':
        form = QuizQuestionForm(request.POST)
        formset = QuizOptionFormSet(request.POST)
        if form.is_valid():
            quiz = form.save(commit=False)
            quiz.task = task
            quiz.save()
            formset.instance = quiz
            formset.save()
            return redirect('task_detail', task_id=task.id)
    else:
        form = QuizQuestionForm()
        formset = QuizOptionFormSet()
    return render(request, 'ccm/quiz/add_quiz.html', {
        'form': form,
        'formset': formset,
        'task': task
    })

