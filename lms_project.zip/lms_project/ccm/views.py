from django.shortcuts import render, redirect, get_object_or_404
from django.http import HttpResponseForbidden
from django.contrib.auth.decorators import login_required
from django.forms import inlineformset_factory

from .models import Course, Task, VideoContent, QuizQuestion, QuizOption, PDFContent
from .forms import (
    TaskForm, VideoContentForm, PDFContentForm,
    QuizQuestionForm, QuizOptionFormSet
)

# --- PDF Upload ---
@login_required
def upload_pdf(request):
    if request.method == 'POST':
        form = PDFContentForm(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            return redirect('ccm:list_pdfs')
    else:
        form = PDFContentForm()
    return render(request, 'ccm/upload_pdf.html', {'form': form})

@login_required
def list_pdfs(request):
    courses = Course.objects.prefetch_related('pdfs')
    return render(request, 'ccm/list_pdfs.html', {'courses': courses})


# --- Course Detail ---
@login_required
def course_detail(request, course_id):
    course = get_object_or_404(Course, id=course_id)
    user = request.user

    if user == course.created_by or user == course.assigned_mentor or course.is_enrolled(user) or user.is_staff:
        return render(request, 'ccm/course_detail.html', {'course': course})
    return HttpResponseForbidden("You do not have access to this course.")


# --- Task List (Dashboard view) ---
@login_required
def task_list(request, course_id):
    course = get_object_or_404(Course, id=course_id)
    if request.user in [course.created_by, course.assigned_mentor] or request.user.is_staff:
        tasks = Task.objects.filter(course=course).order_by('order')
        return render(request, 'ccm/task_list.html', {'course': course, 'tasks': tasks})
    return HttpResponseForbidden("You do not have permission to access this course.")


# --- Task CRUD ---
@login_required
def create_task(request, course_id):
    course = get_object_or_404(Course, id=course_id)
    if request.user in [course.created_by, course.assigned_mentor] or request.user.is_staff:
        if request.method == 'POST':
            form = TaskForm(request.POST)
            if form.is_valid():
                task = form.save(commit=False)
                task.course = course
                task.save()
                return redirect('ccm:task_list', course_id=course.id)
        else:
            form = TaskForm()
        return render(request, 'ccm/create_task.html', {'form': form, 'course': course})
    return HttpResponseForbidden("You do not have permission to create tasks for this course.")

@login_required
def update_task(request, task_id):
    task = get_object_or_404(Task, id=task_id)
    course = task.course
    if request.user in [course.created_by, course.assigned_mentor] or request.user.is_staff:
        if request.method == 'POST':
            form = TaskForm(request.POST, instance=task)
            if form.is_valid():
                form.save()
                return redirect('ccm:task_list', course_id=course.id)
        else:
            form = TaskForm(instance=task)
        return render(request, 'ccm/update_task.html', {'form': form, 'task': task, 'course': course})
    return HttpResponseForbidden("You do not have permission to edit this task.")

@login_required
def delete_task(request, task_id):
    task = get_object_or_404(Task, id=task_id)
    course = task.course
    if request.user in [course.created_by, course.assigned_mentor] or request.user.is_staff:
        if request.method == 'POST':
            task.delete()
            return redirect('ccm:task_list', course_id=course.id)
        return render(request, 'ccm/delete_task.html', {'task': task})
    return HttpResponseForbidden("You do not have permission to delete this task.")


# --- Task Detail for all roles ---
@login_required
def task_detail(request, task_id):
    task = get_object_or_404(Task, id=task_id)
    course = task.course
    user = request.user
    if user in [course.created_by, course.assigned_mentor] or user.is_staff or course.is_enrolled(user):
        videos = task.videos.all()
        quizzes = task.quizzes.all()
        return render(request, 'ccm/task_detail.html', {'task': task, 'videos': videos, 'quizzes': quizzes})
    return HttpResponseForbidden("You do not have permission to view this task.")

def task_detail(request, task_id):
    task = get_object_or_404(Task, id=task_id)
    course = task.course

    # Role check
    if request.user.role == 'learner':
        if request.user not in course.enrolled_learners.all():
            return HttpResponseForbidden("You don't have access to this task.")
        template = 'ccm/learner_task_detail.html'  # learner version
    else:
        template = 'ccm/task_detail.html'  # mentor/admin version

    return render(request, template, {'task': task})



# --- Course Tasks for Learners ---
@login_required
def course_tasks(request, course_id):
    course = get_object_or_404(Course, id=course_id)
    user = request.user
    if user in [course.created_by, course.assigned_mentor] or user.is_staff or course.is_enrolled(user):
        tasks = Task.objects.filter(course=course).order_by('order')
        return render(request, 'ccm/course_tasks.html', {'course': course, 'tasks': tasks})
    return HttpResponseForbidden("You do not have permission to access this course.")


# --- Video Content ---
@login_required
def add_video(request, task_id):
    task = get_object_or_404(Task, id=task_id)
    if request.user in [task.course.created_by, task.course.assigned_mentor] or request.user.is_staff:
        if request.method == 'POST':
            form = VideoContentForm(request.POST)
            if form.is_valid():
                video = form.save(commit=False)
                video.task = task
                video.save()
                return redirect('ccm:task_detail', task_id=task.id)
        else:
            form = VideoContentForm()
        return render(request, 'ccm/video/add_video.html', {'form': form, 'task': task})
    return HttpResponseForbidden("You do not have permission to add video.")

@login_required
def delete_video(request, video_id):
    video = get_object_or_404(VideoContent, id=video_id)
    task = video.task
    course = task.course
    if request.user in [course.created_by, course.assigned_mentor] or request.user.is_staff:
        if request.method == "POST":
            video.delete()
            return redirect('ccm:task_detail', task_id=task.id)
        return render(request, 'ccm/video/delete_video.html', {'video': video, 'task': task})
    return HttpResponseForbidden("You do not have permission to delete this video.")

@login_required
def video_detail(request, video_id):
    video = get_object_or_404(VideoContent, id=video_id)
    return render(request, 'ccm/components/video_player.html', {'video': video})


# --- Quiz Content ---
@login_required
def add_quiz(request, task_id):
    task = get_object_or_404(Task, id=task_id)
    course = task.course
    user = request.user

    if user not in [course.created_by, course.assigned_mentor] and not user.is_staff:
        return HttpResponseForbidden("You do not have permission to add a quiz to this task.")

    if request.method == 'POST':
        form = QuizQuestionForm(request.POST)
        formset = QuizOptionFormSet(request.POST)

        if form.is_valid():
            quiz = form.save(commit=False)
            quiz.task = task
            quiz.save()

            # Save options only for MCQ
            if quiz.question_type == 'mcq':
                formset = QuizOptionFormSet(request.POST, instance=quiz)
                if formset.is_valid():
                    formset.save()

            return redirect('ccm:task_detail', task_id=task.id)
    else:
        form = QuizQuestionForm()
        formset = QuizOptionFormSet()

    return render(request, 'ccm/quiz/add_quiz.html', {
        'form': form,
        'formset': formset,
        'task': task,
    })

@login_required
def delete_quiz(request, quiz_id):
    quiz = get_object_or_404(QuizQuestion, id=quiz_id)
    course = quiz.task.course
    if request.user in [course.created_by, course.assigned_mentor] or request.user.is_staff:
        task_id = quiz.task.id
        quiz.delete()
        return redirect('ccm:task_detail', task_id=task_id)
    return HttpResponseForbidden("You do not have permission to delete this quiz.")


from django.shortcuts import render, get_object_or_404
from course.models import Course
from .models import Task

def learner_course_content_view(request, course_id):
    course = get_object_or_404(Course, id=course_id)

    if request.user not in course.enrolled_learners.all():
        return render(request, 'permission_denied.html', status=403)

    tasks = Task.objects.filter(course=course)
    return render(request, 'ccm/learner_course_content.html', {
        'course': course,
        'tasks': tasks
    })

from django.shortcuts import get_object_or_404, render
from django.contrib.auth.decorators import login_required
from course.models import Course
from ccm.models import Task

@login_required
def course_tasks_for_learner(request, course_id):
    course = get_object_or_404(Course, id=course_id)

    # ✅ Check if the user is enrolled
    if not course.enrolled_learners.filter(id=request.user.id).exists():
        return render(request, 'not_authorized.html', {
            'message': "You are not enrolled in this course."
        })

    tasks = Task.objects.filter(course=course)
    context = {
        'course': course,
        'tasks': tasks
    }
    return render(request, 'ccm/course_tasks.html', context)


def learner_task_detail(request, task_id):
    task = get_object_or_404(Task, id=task_id)

    if request.user.role != 'learner' or task.course not in request.user.enrolled_courses.all():
        return HttpResponseForbidden("You do not have access to this task.")

    return render(request, 'ccm/learner_task_detail.html', {'task': task})
