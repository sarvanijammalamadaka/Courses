# users/urls.py
from django.urls import path
from .views import home, register, CustomLoginView, CustomLogoutView, dashboard_redirect, admin_dashboard, mentor_dashboard, learner_dashboard
from users import views

urlpatterns = [
    path('', home, name='home'),
    path('register/', register, name='register'),
    path('login/', CustomLoginView.as_view(), name='login'),
    path('logout/', CustomLogoutView.as_view(), name='logout'),  # This is your logout URL
    path('dashboard/', dashboard_redirect, name='dashboard_redirect'),
    path('admin-dashboard/', admin_dashboard, name='admin_dashboard'),
    path('mentor-dashboard/', mentor_dashboard, name='mentor_dashboard'),
    path('learner-dashboard/', learner_dashboard, name='learner_dashboard'),
    path('user-list/', views.user_list, name='user_list'),
    path('create-user/', views.create_user, name='create_user'),
    path('dashboard/learner/', views.learner_dashboard, name='learner_dashboard'),
]
