from django.contrib import admin
from .models import CustomUser, Course, Enrollment

# Register the CustomUser model
@admin.register(CustomUser)
class CustomUserAdmin(admin.ModelAdmin):
    list_display = ('username', 'email', 'role', 'unique_id')  # Customize which fields to display in the admin
    list_filter = ('role',)  # Add filters to easily filter by role
    search_fields = ('username', 'email')  # Add search functionality for username and email

# Register the Course model
@admin.register(Course)
class CourseAdmin(admin.ModelAdmin):
    list_display = ('name', 'description')  # Display name and description in the admin
    search_fields = ('name',)  # Allow searching by course name

# Register the Enrollment model
@admin.register(Enrollment)
class EnrollmentAdmin(admin.ModelAdmin):
    list_display = ('user', 'course', 'date_enrolled')  # Display user, course, and enrollment date
    list_filter = ('course',)  # Filter by course
    search_fields = ('user__username', 'course__name')  # Search by username and course name
