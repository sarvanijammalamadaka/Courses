from django.contrib.auth.models import AbstractUser
from django.db import models
import uuid
from django.contrib.auth import get_user_model

# Custom User model
class CustomUser(AbstractUser):
    ROLE_CHOICES = [
        ('admin', 'Admin'),
        ('mentor', 'Mentor'),
        ('learner', 'Learner'),
    ]
    role = models.CharField(max_length=10, choices=ROLE_CHOICES)  # Field to define user role
    unique_id = models.CharField(max_length=20, unique=True, blank=True, null=True)  # Unique identifier for each user

    def save(self, *args, **kwargs):
        if not self.unique_id:
            prefix = self.role[:2].upper()  # Take first two letters of role and capitalize
            self.unique_id = f"{prefix}-{uuid.uuid4().hex[:8].upper()}"  # Generate a unique ID with role prefix and UUID
        super().save(*args, **kwargs)  # Call the parent class's save method

    def __str__(self):
        return self.username  # Return the username when the object is printed

# Course model
class Course(models.Model):
    name = models.CharField(max_length=100)  # Name of the course
    description = models.TextField()  # Description of the course

    def __str__(self):
        return self.name  # Return the course name when the object is printed

# Enrollment model to track which user is enrolled in which course
class Enrollment(models.Model):
    user = models.ForeignKey(get_user_model(), on_delete=models.CASCADE)  # User enrolled in the course
    course = models.ForeignKey(Course, on_delete=models.CASCADE)  # Course that the user is enrolled in
    date_enrolled = models.DateField(auto_now_add=True)  # Date when the user was enrolled in the course

    def __str__(self):
        return f'{self.user} enrolled in {self.course}'  # Return a string showing the user and the course they are enrolled in
