from django.db import models
from django.conf import settings
from course.models import Course


class Task(models.Model):
    course = models.ForeignKey(Course, on_delete=models.CASCADE, related_name='tasks')
    title = models.CharField(max_length=255)
    description = models.TextField(blank=True)
    order = models.PositiveIntegerField(default=1)
    completed_by = models.ManyToManyField(settings.AUTH_USER_MODEL, related_name='completed_tasks', blank=True)

    class Meta:
        ordering = ['order']

    def __str__(self):
        return f"{self.course.title} - Task {self.order}: {self.title}"


class VideoContent(models.Model):
    task = models.ForeignKey(Task, on_delete=models.CASCADE, related_name='videos')
    title = models.CharField(max_length=255)
    embed_url = models.URLField(blank=True, null=True)  # For YouTube or external links
    file = models.FileField(upload_to='videos/', blank=True, null=True)  # For uploaded videos
    description = models.TextField(blank=True, null=True)
    published_at = models.DateTimeField(auto_now_add=True)
    youtube_url = models.URLField(max_length=200, blank=False, default="https://www.youtube.com/embed/default")

    def __str__(self):
        return self.title

    def get_embed_url(self):
        """
        Converts a standard YouTube URL into an embed URL.
        Example: https://www.youtube.com/watch?v=VIDEO_ID -> https://www.youtube.com/embed/VIDEO_ID
        """
        if self.embed_url and "youtube.com/watch" in self.embed_url:
            video_id = self.embed_url.split("v=")[-1].split("&")[0]
            return f"https://www.youtube.com/embed/{video_id}"
        elif self.embed_url and "youtu.be/" in self.embed_url:
            video_id = self.embed_url.split("youtu.be/")[-1]
            return f"https://www.youtube.com/embed/{video_id}"
        return self.embed_url

    def save(self, *args, **kwargs):
        if self.youtube_url and "youtube.com/watch" in self.youtube_url:
            video_id = self.youtube_url.split("v=")[-1].split("&")[0]
            self.youtube_url = f"https://www.youtube.com/embed/{video_id}"
        elif self.youtube_url and "youtu.be/" in self.youtube_url:
            video_id = self.youtube_url.split("youtu.be/")[-1]
            self.youtube_url = f"https://www.youtube.com/embed/{video_id}"
        super().save(*args, **kwargs)


class PDFContent(models.Model):
    course = models.ForeignKey(Course, on_delete=models.CASCADE, related_name='pdfs')
    title = models.CharField(max_length=255)
    description = models.TextField(blank=True)
    pdf_file = models.FileField(upload_to='pdf_uploads/')
    uploaded_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.title} - {self.course.title}"


class QuizQuestion(models.Model):
    QUESTION_TYPE_CHOICES = [
        ('mcq', 'Multiple Choice'),
        ('short', 'Short Answer'),
    ]

    task = models.ForeignKey(Task, on_delete=models.CASCADE, related_name='quizzes')
    video = models.ForeignKey(VideoContent, on_delete=models.CASCADE, related_name='quizzes', null=True, blank=True)
    timestamp = models.PositiveIntegerField(help_text="Timestamp in seconds (e.g., 120 = 2:00)")
    question_type = models.CharField(max_length=10, choices=QUESTION_TYPE_CHOICES)
    question_text = models.TextField()
    correct_answer = models.TextField(help_text="For MCQ: correct option text, For Short: expected answer")
    explanation = models.TextField(blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"Quiz at {self.timestamp}s - {self.question_text[:30]}"


class QuizOption(models.Model):
    question = models.ForeignKey(QuizQuestion, on_delete=models.CASCADE, related_name='options')
    option_text = models.CharField(max_length=255)

    def __str__(self):
        return f"Option for: {self.question.question_text[:30]}"
