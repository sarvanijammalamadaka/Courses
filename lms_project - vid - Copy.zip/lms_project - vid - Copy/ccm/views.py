from django.shortcuts import render, redirect, get_object_or_404
from django.http import HttpResponseForbidden, HttpResponse
from django.contrib.auth.decorators import login_required
from reportlab.pdfgen import canvas
from io import BytesIO
from .models import Course, Task, VideoContent, QuizQuestion, QuizOption, PDFContent
from .forms import TaskForm, VideoContentForm, PDFContentForm, QuizQuestionForm, QuizOptionFormSet

# --- PDF Upload ---
@login_required
def upload_pdf(request):
    if request.method == 'POST':
        form = PDFContentForm(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            return redirect('ccm:list_pdfs')
    else:
        form = PDFContentForm()
    return render(request, 'ccm/upload_pdf.html', {'form': form})

@login_required
def list_pdfs(request):
    courses = Course.objects.prefetch_related('pdfs')
    return render(request, 'ccm/list_pdfs.html', {'courses': courses})

# --- Course Detail ---
@login_required
def course_detail(request, course_id):
    course = get_object_or_404(Course, id=course_id)
    user = request.user
    if user == course.created_by or user == course.assigned_mentor or course.is_enrolled(user) or user.is_staff:
        return render(request, 'ccm/course_detail.html', {'course': course})
    return HttpResponseForbidden("You do not have access to this course.")

# --- Task List ---
@login_required
def task_list(request, course_id):
    course = get_object_or_404(Course, id=course_id)
    if request.user in [course.created_by, course.assigned_mentor] or request.user.is_staff:
        tasks = Task.objects.filter(course=course).order_by('order')
        return render(request, 'ccm/task_list.html', {'course': course, 'tasks': tasks})
    return HttpResponseForbidden("You do not have permission to access this course.")

# --- Task CRUD ---
@login_required
def create_task(request, course_id):
    course = get_object_or_404(Course, id=course_id)
    if request.user in [course.created_by, course.assigned_mentor] or request.user.is_staff:
        if request.method == 'POST':
            form = TaskForm(request.POST)
            if form.is_valid():
                task = form.save(commit=False)
                task.course = course
                task.save()
                return redirect('ccm:task_list', course_id=course.id)
        else:
            form = TaskForm()
        return render(request, 'ccm/create_task.html', {'form': form, 'course': course})
    return HttpResponseForbidden("You do not have permission to create tasks for this course.")

@login_required
def update_task(request, task_id):
    task = get_object_or_404(Task, id=task_id)
    course = task.course
    if request.user in [course.created_by, course.assigned_mentor] or request.user.is_staff:
        if request.method == 'POST':
            form = TaskForm(request.POST, instance=task)
            if form.is_valid():
                form.save()
                return redirect('ccm:task_list', course_id=course.id)
        else:
            form = TaskForm(instance=task)
        return render(request, 'ccm/update_task.html', {'form': form, 'task': task, 'course': course})
    return HttpResponseForbidden("You do not have permission to edit this task.")

@login_required
def delete_task(request, task_id):
    task = get_object_or_404(Task, id=task_id)
    course = task.course
    if request.user in [course.created_by, course.assigned_mentor] or request.user.is_staff:
        if request.method == 'POST':
            task.delete()
            return redirect('ccm:task_list', course_id=course.id)
        return render(request, 'ccm/delete_task.html', {'task': task})
    return HttpResponseForbidden("You do not have permission to delete this task.")

# --- Task Detail ---
@login_required
def task_detail(request, task_id):
    task = get_object_or_404(Task, id=task_id)
    course = task.course
    user = request.user

    if user in [course.created_by, course.assigned_mentor] or user.is_staff or course.is_enrolled(user):
        videos = task.videos.all()
        quizzes = task.quizzes.all()
        pdfs = course.pdfs.all()
        is_completed = task.completed_by.filter(id=user.id).exists()

        # Calculate progress
        total_tasks = course.tasks.count()
        completed_tasks = course.tasks.filter(completed_by=user).count()

        # Progress calculation remains the same
        progress = int((completed_tasks / total_tasks) * 100) if total_tasks > 0 else 0

        return render(request, 'ccm/task_detail.html', {
            'task': task,
            'videos': videos,
            'quizzes': quizzes,
            'pdfs': pdfs,
            'is_completed': is_completed,
            'progress': progress
        })

    return HttpResponseForbidden("You do not have permission to view this task.")

# --- Video Content ---
@login_required
def add_video(request, task_id):
    task = get_object_or_404(Task, id=task_id)
    if request.user.role == 'learner':  # Restrict learners
        return HttpResponseForbidden("You do not have permission to add videos.")
    if request.method == 'POST':
        form = VideoContentForm(request.POST)
        if form.is_valid():
            video = form.save(commit=False)
            video.task = task
            video.save()
            return redirect('ccm:task_detail', task_id=task.id)
    else:
        form = VideoContentForm()
    return render(request, 'ccm/video/add_video.html', {'form': form, 'task': task})

@login_required
def delete_video(request, video_id):
    video = get_object_or_404(VideoContent, id=video_id)
    if request.user.role == 'learner':  # Restrict learners
        return HttpResponseForbidden("You do not have permission to delete videos.")
    task_id = video.task.id
    video.delete()
    return redirect('ccm:task_detail', task_id=task_id)

@login_required
def play_video(request, video_id):
    video = get_object_or_404(VideoContent, id=video_id)
    task = video.task
    embed_url = video.get_embed_url()
    return render(request, 'ccm/video/play_video.html', {'video': video, 'task': task, 'embed_url': embed_url})

@login_required
def video_detail(request, video_id):
    video = get_object_or_404(VideoContent, id=video_id)
    return render(request, 'ccm/video/video_detail.html', {'video': video})

@login_required
def update_video(request, video_id):
    video = get_object_or_404(VideoContent, id=video_id)
    if request.user.role == 'learner':  # Restrict learners
        return HttpResponseForbidden("You do not have permission to edit videos.")
    task = video.task
    if request.method == 'POST':
        form = VideoContentForm(request.POST, request.FILES, instance=video)
        if form.is_valid():
            form.save()
            return redirect('ccm:task_detail', task_id=task.id)
    else:
        form = VideoContentForm(instance=video)
    return render(request, 'ccm/video/update_video.html', {'form': form, 'video': video, 'task': task})

# --- Quiz Content ---
@login_required
def add_quiz(request, task_id):
    task = get_object_or_404(Task, id=task_id)
    if request.user.role == 'learner':  # Restrict learners
        return HttpResponseForbidden("You do not have permission to add quizzes.")
    if request.method == 'POST':
        form = QuizQuestionForm(request.POST)
        formset = QuizOptionFormSet(request.POST)
        if form.is_valid():
            quiz = form.save(commit=False)
            quiz.task = task
            quiz.save()
            if formset.is_valid():
                formset.instance = quiz
                formset.save()
            return redirect('ccm:task_detail', task_id=task.id)
    else:
        form = QuizQuestionForm()
        formset = QuizOptionFormSet()
    return render(request, 'ccm/quiz/add_quiz.html', {'form': form, 'formset': formset, 'task': task})

@login_required
def delete_quiz(request, quiz_id):
    quiz = get_object_or_404(QuizQuestion, id=quiz_id)
    if request.user.role == 'learner':  # Restrict learners
        return HttpResponseForbidden("You do not have permission to delete quizzes.")
    task_id = quiz.task.id
    quiz.delete()
    return redirect('ccm:task_detail', task_id=task_id)

@login_required
def attempt_quiz(request, quiz_id):
    quiz = get_object_or_404(QuizQuestion, id=quiz_id)
    if request.user.role != 'learner':
        return HttpResponseForbidden("Only learners can attempt quizzes.")
    
    if request.method == 'POST':
        user_answer = request.POST.get('answer')
        # Logic to evaluate the answer can be added here
        return render(request, 'ccm/quiz/quiz_result.html', {'quiz': quiz, 'user_answer': user_answer})
    
    return render(request, 'ccm/quiz/attempt_quiz.html', {'quiz': quiz})

# --- Course Tasks ---
@login_required
def course_tasks(request, course_id):
    course = get_object_or_404(Course, id=course_id)
    user = request.user
    if user in [course.created_by, course.assigned_mentor] or user.is_staff or course.is_enrolled(user):
        tasks = Task.objects.filter(course=course).order_by('order')
        return render(request, 'ccm/course_tasks.html', {'course': course, 'tasks': tasks})
    return HttpResponseForbidden("You do not have permission to access this course.")

# --- Learner Course Content ---
@login_required
def learner_course_content_view(request, course_id):
    course = get_object_or_404(Course, id=course_id)
    user = request.user

    # Check if the user is enrolled in the course
    if not course.enrolled_learners.filter(id=user.id).exists():
        return render(request, 'ccm/permission_denied.html', status=403)

    tasks = Task.objects.filter(course=course).order_by('order')
    total_tasks = tasks.count()
    completed_tasks = tasks.filter(completed_by=user).count()
    all_tasks_completed = total_tasks > 0 and total_tasks == completed_tasks

    return render(request, 'ccm/learner_course_content.html', {
        'course': course,
        'tasks': tasks,
        'all_tasks_completed': all_tasks_completed
    })

@login_required
def mark_task_completed(request, task_id):
    task = get_object_or_404(Task, id=task_id)
    course = task.course
    user = request.user

    if user.role == 'learner':
        # Mark the task as completed
        task.completed_by.add(user)
        task.save()

        # Redirect back to task_detail
        return redirect('ccm:task_detail', task_id=task.id)

    return HttpResponseForbidden("You do not have permission to mark this task as completed.")

@login_required
def generate_certificate(request, course_id):
    course = get_object_or_404(Course, id=course_id)
    user = request.user

    # Ensure the user has completed all tasks
    tasks = Task.objects.filter(course=course)
    if tasks.count() == tasks.filter(completed_by=user).count():
        # Generate the PDF certificate
        buffer = BytesIO()
        p = canvas.Canvas(buffer)

        # Certificate content
        p.setFont("Helvetica-Bold", 24)
        p.drawString(200, 750, "Certificate of Completion")
        p.setFont("Helvetica", 18)
        p.drawString(100, 700, f"This certifies that {user.get_full_name()} {user.username}")
        p.drawString(100, 650, f"has successfully completed the course:")
        p.setFont("Helvetica-Bold", 20)
        p.drawString(100, 600, f"{course.title}")
        p.setFont("Helvetica", 16)
        p.drawString(100, 550, f"Date: {course.updated_at.strftime('%B %d, %Y')}")

        # Finalize the PDF
        p.showPage()
        p.save()
        buffer.seek(0)

        # Return the PDF as a downloadable response
        response = HttpResponse(buffer, content_type='application/pdf')
        response['Content-Disposition'] = f'attachment; filename="{course.title}_certificate.pdf"'
        return response

    return HttpResponseForbidden("You must complete all tasks to download the certificate.")
