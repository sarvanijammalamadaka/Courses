from django.urls import path
from . import views

app_name = 'ccm'

urlpatterns = [
    # Task management
    path('course/<int:course_id>/tasks/', views.task_list, name='task_list'),
    path('course/<int:course_id>/tasks/create/', views.create_task, name='create_task'),
    path('task/<int:task_id>/update/', views.update_task, name='update_task'),
    path('task/<int:task_id>/delete/', views.delete_task, name='delete_task'),
    path('task/<int:task_id>/', views.task_detail, name='task_detail'),
    path('task/<int:task_id>/mark-completed/', views.mark_task_completed, name='mark_task_completed'),

    # Course detail & task list for learners
    path('course/<int:course_id>/content/', views.learner_course_content_view, name='learner_course_content'),
    path('course/<int:course_id>/detail/', views.course_detail, name='course_detail'),

    # Video content
    path('task/<int:task_id>/add-video/', views.add_video, name='add_video'),
    path('video/<int:video_id>/delete/', views.delete_video, name='delete_video'),
    path('video/<int:video_id>/', views.video_detail, name='video_detail'),  # Ensure this matches the view
    path('video/<int:video_id>/play/', views.play_video, name='play_video'),
    path('video/<int:video_id>/update/', views.update_video, name='update_video'),

    # Quiz content
    path('task/<int:task_id>/add-quiz/', views.add_quiz, name='add_quiz'),
    path('quiz/<int:quiz_id>/delete/', views.delete_quiz, name='delete_quiz'),
    path('quiz/attempt/<int:quiz_id>/', views.attempt_quiz, name='attempt_quiz'),

    # PDF content
    path('pdfs/upload/', views.upload_pdf, name='upload_pdf'),
    path('pdfs/', views.list_pdfs, name='list_pdfs'),

    # Certificate generation
    path('course/<int:course_id>/certificate/', views.generate_certificate, name='generate_certificate'),
]