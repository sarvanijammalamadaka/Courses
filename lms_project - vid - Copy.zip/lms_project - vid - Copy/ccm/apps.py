from django.apps import AppConfig


class CcmConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'ccm'
