from django import forms
from django.forms import inlineformset_factory
from .models import (
    PDFContent,
    Task,
    VideoContent,
    QuizQuestion,
    QuizOption
)
import re

# --- PDF Upload Form ---
class PDFContentForm(forms.ModelForm):
    class Meta:
        model = PDFContent
        fields = ['course', 'title', 'description', 'pdf_file']


# --- Task Form (Create/Update) ---
class TaskForm(forms.ModelForm):
    class Meta:
        model = Task
        fields = ['title', 'description', 'order']


# --- Video Content Form ---
class VideoContentForm(forms.ModelForm):
    youtube_url = forms.URLField(required=True, label="YouTube URL")

    def clean_youtube_url(self):
        url = self.cleaned_data['youtube_url']
        youtube_regex = r'(https?://)?(www\.)?(youtube\.com|youtu\.be)/(watch\?v=|embed/)?[a-zA-Z0-9_-]+'
        if not re.match(youtube_regex, url):
            raise forms.ValidationError("Enter a valid YouTube URL.")
        return url

    class Meta:
        model = VideoContent
        fields = ['title', 'file', 'youtube_url', 'description']  # Ensure youtube_url is included


# --- Quiz Question Form ---
class QuizQuestionForm(forms.ModelForm):
    class Meta:
        model = QuizQuestion
        fields = [
            'video',
            'timestamp',
            'question_type',  # Choices: "mcq", "short"
            'question_text',
            'correct_answer',
            'explanation'
        ]


# --- Quiz Option Form (Inline Formset) ---
QuizOptionFormSet = inlineformset_factory(
    QuizQuestion,
    QuizOption,
    fields=('option_text',),
    extra=4,
    can_delete=True
)
