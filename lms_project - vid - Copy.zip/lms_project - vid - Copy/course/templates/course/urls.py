from django.urls import path
from . import views

urlpatterns = [
    path('create-course/', views.create_course, name='create_course'),
    path('approve-courses/', views.approve_courses, name='approve_courses'),
    path('approve-course/<int:course_id>/', views.approve_or_reject_course, name='approve_or_reject_course'),
    path('learner-course-page/', views.learner_course_page, name='learner_course_page'),
    path('update-course/<int:course_id>/', views.update_course, name='update_course'),
]
