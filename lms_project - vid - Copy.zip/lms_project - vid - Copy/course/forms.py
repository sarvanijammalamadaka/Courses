from django import forms
from .models import Course
from users.models import CustomUser  # adjust if you're using get_user_model()

class CourseForm(forms.ModelForm):
    class Meta:
        model = Course
        fields = ['title', 'description']
        widgets = {
            'title': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Enter course title'}),
            'description': forms.Textarea(attrs={'class': 'form-control', 'rows': 4, 'placeholder': 'Enter course description'}),
        }

class AssignMentorForm(forms.Form):
    mentor = forms.ModelChoiceField(
        queryset=CustomUser.objects.filter(role='mentor'),
        required=False,
        widget=forms.Select(attrs={'class': 'form-control'})
    )
