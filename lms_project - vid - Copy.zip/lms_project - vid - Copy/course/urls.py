from django.urls import path
from . import views

urlpatterns = [
    # Create a new course (Admin or Mentor)
    path('create-course/', views.create_course, name='create_course'),

    # Update a specific course
    path('update-course/<int:course_id>/', views.update_course, name='update_course'),

    # Delete a specific course
    path('delete/<int:course_id>/', views.delete_course, name='delete_course'),

    # General course list (Admin sees all, Mentor sees assigned, Learner sees enrolled)
    path('course-list/', views.course_list, name='course_list'),

    # Learner's enrolled courses (dashboard view)
    path('my-courses/', views.my_courses, name='my_courses'),

    # Mentor's assigned courses
    path('mentor-assigned-courses/', views.mentor_assigned_courses, name='mentor_assigned_courses'),

    # Admin view: list of courses pending approval
    path('approve-courses/', views.approve_courses, name='approve_courses'),

    # Admin view: approve/reject individual course
    path('approve-course/<int:course_id>/', views.approve_or_reject_course, name='approve_or_reject_course'),

    # Learner enrollment request for a course
    path('enroll/<int:course_id>/', views.request_enrollment, name='request_enrollment'),
]
