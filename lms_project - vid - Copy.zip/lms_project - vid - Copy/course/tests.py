# course/tests.py

from django.test import TestCase
from django.urls import reverse
from .models import Course
from django.contrib.auth import get_user_model

class CourseManagementTestCase(TestCase):
    def test_learner_create_course(self):
        # Ensure the user is logged in as a learner
        learner = get_user_model().objects.create_user(username='learner', password='password', role='learner')
        self.client.login(username='learner', password='password')
        
        response = self.client.post(reverse('create_course'), {'title': 'Learner Course', 'description': 'Learner Description'})
        self.assertEqual(response.status_code, 302)  # Check for a redirect (to learner course page)

    def test_admin_create_course(self):
        # Ensure the user is logged in as admin
        admin = get_user_model().objects.create_user(username='admin', password='password', role='admin')
        self.client.login(username='admin', password='password')
        
        response = self.client.post(reverse('create_course'), {'title': 'Test Course', 'description': 'Test Description'})
        self.assertEqual(response.status_code, 403)  # Admin shouldn't create courses, so it should be forbidden

    def test_approve_course(self):
        # Test admin approving a course
        admin = get_user_model().objects.create_user(username='admin', password='password', role='admin')
        learner = get_user_model().objects.create_user(username='learner', password='password', role='learner')
        self.client.login(username='admin', password='password')
        
        course = Course.objects.create(title='Test Course', description='Test Description', created_by=learner, status='pending')
        response = self.client.post(reverse('approve_or_reject_course', args=[course.id]), {'status': 'approved'})
        self.assertEqual(response.status_code, 302)  # After approval, should redirect

    def test_learner_access(self):
        # Test learner viewing their course page
        learner = get_user_model().objects.create_user(username='learner', password='password', role='learner')
        self.client.login(username='learner', password='password')
        
        response = self.client.get(reverse('learner_course_page'))
        self.assertEqual(response.status_code, 200)  # Should access learner course page

    def test_mentor_access(self):
        # Test mentor access to learner course page (should be forbidden)
        mentor = get_user_model().objects.create_user(username='mentor', password='password', role='mentor')
        self.client.login(username='mentor', password='password')
        
        response = self.client.get(reverse('learner_course_page'))
        self.assertEqual(response.status_code, 403)  # Should be forbidden
