from django.shortcuts import render, redirect
from django.contrib.auth import login
from django.contrib.auth.views import LoginView, LogoutView
from .forms import CustomUserCreationForm
from django.http import HttpResponse
from django.urls import reverse_lazy
from django.contrib.auth.decorators import login_required
from .models import Course, Enrollment  # Ensure your models are correctly imported

# Home view redirecting to login or dashboard
def home(request):
    if request.user.is_authenticated:
        return redirect('dashboard_redirect')
    return redirect('login')

# Registration View
def register(request):
    if request.method == 'POST':
        form = CustomUserCreationForm(request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user)
            return redirect_dashboard(user)
    else:
        form = CustomUserCreationForm()
    return render(request, 'users/register.html', {'form': form})

# Redirects based on user role after login
def redirect_dashboard(user):
    if user.role == 'admin':
        return redirect('admin_dashboard')
    elif user.role == 'mentor':
        return redirect('mentor_dashboard')
    elif user.role == 'learner':
        return redirect('learner_dashboard')
    return redirect('home')

# Login View
class CustomLoginView(LoginView):
    template_name = 'users/login.html'

    def get_success_url(self):
        return reverse_lazy('dashboard_redirect')

# Logout View
class CustomLogoutView(LogoutView):
    next_page = 'login'  # Redirect to login page after logging out

# Dashboard Redirection
@login_required
def dashboard_redirect(request):
    role = request.user.role
    if role == 'admin':
        return redirect('admin_dashboard')
    elif role == 'mentor':
        return redirect('mentor_dashboard')
    elif role == 'learner':
        return redirect('learner_dashboard')
    return redirect('login')

from .models import Course
# Admin Dashboard View
@login_required
def admin_dashboard(request):
    # Example context data to pass to the template
    total_users = 100  # Replace with your actual data logic
    total_courses = 50  # Replace with your actual data logic
    total_enrollments = 200  # Replace with your actual data logic
    courses = Course.objects.all()
    return render(request, 'users/dashboard/admin_dashboard.html', {
        'total_users': total_users,
        'total_courses': total_courses,
        'total_enrollments': total_enrollments,
        'courses': courses
    })












# Mentor Dashboard View
@login_required
def mentor_dashboard(request):
    # Add logic to fetch mentor-specific data if needed
    return render(request, 'users/dashboard/mentor_dashboard.html')

# Learner Dashboard View
@login_required
def learner_dashboard(request):
    # Get the courses the learner is enrolled in
    enrolled_courses = Enrollment.objects.filter(user=request.user)
    courses = [enrollment.course for enrollment in enrolled_courses]
    
    return render(request, 'users/dashboard/learner_dashboard.html', {'courses': courses})

# In users/views.py
from django.shortcuts import render
from django.contrib.auth.models import User  # Use User model to list users

def user_list(request):
    users = User.objects.all()  # Fetch all users from the User model
    return render(request, 'users/user_list.html', {'users': users})

# users/views.py
from django.shortcuts import render, redirect
from django.contrib.auth.models import User
from django.contrib.auth.forms import UserCreationForm
from django.http import HttpResponseForbidden
from django.contrib.auth.decorators import login_required

# View to create a new user
from django.shortcuts import render, redirect
from .forms import CustomUserCreationForm

def create_user(request):
    if request.method == 'POST':
        form = CustomUserCreationForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('user_list')  # Replace with your actual view name
    else:
        form = CustomUserCreationForm()
    return render(request, 'users/create_user.html', {'form': form})


from django.contrib.auth import get_user_model
User = get_user_model()

def user_list(request):
    users = User.objects.all()  # ✅ This works with your CustomUser
    return render(request, 'users/user_list.html', {'users': users})


from django.contrib.auth.decorators import login_required
from django.http import HttpResponseForbidden
from django.shortcuts import render
from course.models import Course

@login_required
def mentor_dashboard(request):
    if request.user.role != 'mentor':
        return HttpResponseForbidden("Unauthorized access.")

    # Filter by correct field: assigned_mentor
    assigned_courses = Course.objects.filter(assigned_mentor=request.user, status='approved')
    pending_courses = Course.objects.filter(assigned_mentor=request.user, status='pending')

    context = {
        'assigned_courses': assigned_courses,
        'pending_courses': pending_courses,
    }
    return render(request, 'users/dashboard/mentor_dashboard.html', context)


from django.shortcuts import render
from course.models import Course  # Import the Course model

from course.models import Course

def learner_dashboard(request):
    user = request.user

    enrolled_courses = user.enrolled_courses.all()  # Now this will work
    created_courses = Course.objects.filter(created_by=user)
    pending_courses = created_courses.filter(status='pending')
    approved_courses = created_courses.filter(status='approved')

    available_courses = Course.objects.filter(status='approved').exclude(enrolled_learners=user)

    context = {
        'enrolled_courses': enrolled_courses,
        'created_courses': created_courses,
        'pending_courses': pending_courses,
        'approved_courses': approved_courses,
        'available_courses': available_courses,
    }
    return render(request, 'users/dashboard/learner_dashboard.html', context)


# users/views.py (admin_dashboard)
def admin_dashboard(request):
    courses = Course.objects.all()
    return render(request, 'users/dashboard/admin_dashboard.html', {'courses': courses})
